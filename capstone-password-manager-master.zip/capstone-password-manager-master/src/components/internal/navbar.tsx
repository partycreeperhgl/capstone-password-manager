import {GetSession} from "@/components/internal/getSession";
import {auth} from "@/auth";
import Link from "next/link";
import {CircleUser, Menu, Package2} from "lucide-react";
import {Sheet, SheetContent, SheetTrigger} from "@/components/ui/sheet";
import {Button} from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {Avatar, AvatarFallback, AvatarImage} from "@/components/ui/avatar";
import {Logout} from "@/components/common/Logout";
import {Theme} from "@/components/internal/theme";

export const Navbar = async () => {
  const session = await auth();

  return (
    <header className="sticky z-20 top-0 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
      <GetSession sessionInfo={session}/>
      <nav
        className="hidden flex-col gap-6 text-lg font-medium md:flex md:flex-row md:items-center md:gap-5 md:text-sm lg:gap-6">
        <Link
          href="/"
          className="flex items-center gap-2 text-lg font-semibold md:text-base"
        >
          <svg className={'w-10 h-10'} viewBox="0 0 81 81" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M60.75 27H57.375V20.25C57.375 10.935 49.815 3.375 40.5 3.375C31.185 3.375 23.625 10.935 23.625 20.25V27H20.25C16.5375 27 13.5 30.0375 13.5 33.75V67.5C13.5 71.2125 16.5375 74.25 20.25 74.25H60.75C64.4625 74.25 67.5 71.2125 67.5 67.5V33.75C67.5 30.0375 64.4625 27 60.75 27ZM30.0375 20.25C30.0375 14.4787 34.7287 9.7875 40.5 9.7875C46.2713 9.7875 50.9625 14.4787 50.9625 20.25V27H30.0375V20.25ZM54 54H43.875V64.125H37.125V54H27V47.25H37.125V37.125H43.875V47.25H54V54Z"
              fill="currentColor"/>
          </svg>
          <span className="sr-only">Capstone Password Manager</span>
        </Link>
        <Link
          href="/generator"
          className="text-foreground transition-colors hover:text-foreground"
        >
          Generator
        </Link>
      </nav>
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="outline" size="icon" className="shrink-0 md:hidden">
            <Menu className="h-5 w-5"/>
            <span className="sr-only">Toggle navigation menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left">
          <nav className="grid gap-6 text-lg font-medium">
            <Link
              href="#"
              className="flex items-center gap-2 text-lg font-semibold"
            >
              <Package2 className="h-6 w-6"/>
              <span className="sr-only">Acme Inc</span>
            </Link>
            <Link href="/generator" className="hover:text-foreground">
              Generator
            </Link>
          </nav>
        </SheetContent>
      </Sheet>
      <div className="flex w-full items-center gap-4 md:ml-auto md:gap-2 lg:gap-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="secondary" size="icon" className=" ml-auto rounded-full">
              {!session ? (
                <CircleUser className="h-5 w-5"/>
              ) : (
                <Avatar>
                  <AvatarImage src={session.user.image}/>
                  <AvatarFallback>
                    {session.user.name || session.user.email}
                  </AvatarFallback>
                </Avatar>
              )}
              <span className="sr-only">Toggle user menu</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {!session ? (
              <DropdownMenuLabel>
                <Theme/>
                <DropdownMenuSeparator/>
                <DropdownMenuItem asChild>
                  <Link href={"/signin"} className="hover:text-foreground">
                    Sign in
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuLabel>
            ) : (
              <>
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator/>
                <DropdownMenuItem>Settings</DropdownMenuItem>
                <DropdownMenuItem>Support</DropdownMenuItem>
                <DropdownMenuSeparator/>
                <Theme/>
                <DropdownMenuSeparator/>
                <Logout>
                  <DropdownMenuItem>
                    Logout
                  </DropdownMenuItem>
                </Logout>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};
