import { routes } from "@/auth";

export const GET = routes.GET;
